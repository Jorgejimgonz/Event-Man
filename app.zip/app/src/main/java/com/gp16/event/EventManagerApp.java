package com.gp16.event;

import com.gp16.event.view.ManagementApp;

public class EventManagerApp {
    public static void main(String[] args) {
        ManagementApp.main(args);
    }
} 